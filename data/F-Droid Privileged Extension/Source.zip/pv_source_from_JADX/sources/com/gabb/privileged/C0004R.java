package com.gabb.privileged;

/* renamed from: com.gabb.privileged.R */
public final class C0004R {

    /* renamed from: com.gabb.privileged.R$mipmap */
    public static final class mipmap {
        public static final int ic_launcher = 2130771968;

        private mipmap() {
        }
    }

    /* renamed from: com.gabb.privileged.R$string */
    public static final class string {
        public static final int app_name = 2130837504;

        private string() {
        }
    }

    private C0004R() {
    }
}
